# isev-ACF-Wordpress-template
isev's WordPress Template, that uses Bedrock as a base (https://roots.io/bedrock/).

## Installation
1. Clone this repository
2. Set up an auth.json file in the project root. As this requires ACF.
2. Run `composer install` in the project root (this will require you to have composer installed on your machine)
3. Create a `.env` file in the project root. You can copy the `.env.example` file and modify it to your needs.
4. **IMPORTANT** remove .git folder and run `git init` to start a new git repository (if you are using this as a template for a new project)
## plugins included
- Advanced Custom Fields Pro
- aryo-activity-log
- imagify
- wp-rocket (please add the key to the env file)
- isev sage theme (The theme is a framework and should be updated without a child theme)
#### Remove or add plugins where necessary (refer to adding new plugins below)

# Theme Setup
## isev acf theme for wordpress
This is a custom theme for the isev website. It uses the Advanced Custom Fields plugin to create custom fields for the site. It is all built on top of roots/sage.

### Installation
1. Navigate to the theme directory and run `composer install` to install the necessary dependencies.
2. Run `yarn` to install the necessary node modules.
3. Check your bud.config.js file to make sure the site url (REPLACE_WITH_YOUR_LOCAL_URL) is set to the correct URL.
4. Run `yarn build` to build the theme.

# Useful information
## server folder structure
You will need to set the root of your server to the `web` folder. This is where the WordPress installation is located.

## Development tips
### Adding new plugins:
You can add additional plugins by running `composer require wpackagist-plugin/plugin-name` in the project root.

### Adding new themes:
You can add additional themes by running `composer require wpackagist-theme/theme-name` in the project root.

### Theme development:
By default, this package will install the `wpackagist-theme/twentytwenty` theme. You can change this by modifying the `composer.json` file.
Be sure to add a child theme to the `web/app/themes` directory if you want to make changes to the theme.

### Plugin development:
You can add plugins to the `web/app/plugins` directory. Be sure to add them to the .gitkeep file so they are included in the repository.

### Bedrock documentation:
For more information on Bedrock, please refer to the [official documentation](https://roots.io/bedrock/docs/).

### WP packagist:
For more information on WP packagist, please refer to the [official documentation](https://wpackagist.org/).

### Sage documentation: 
For more information on Sage, please refer to the [official documentation](https://roots.io/sage/docs/).

