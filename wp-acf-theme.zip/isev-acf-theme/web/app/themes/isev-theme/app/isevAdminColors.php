<?php

namespace App;

/**
 * isev color scheme
 */

//load isev color scheme & login page
add_action('admin_enqueue_scripts', function () {
    wp_enqueue_style('isev-admin-colors', get_template_directory_uri() . '/resources/styles/isevAdminColors.css', false, '1.0.0');
});

add_action('login_enqueue_scripts', function () {
    wp_enqueue_style('isev-admin-colors', get_template_directory_uri() . '/resources/styles/isevAdminColors.css', false, '1.0.0');
});
